var mtop = document.all ? document.getElementsByTagName("html")[0].offsetHeight : window.innerHeight;
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return false;
}

function checkCookie() {
    var user = getCookie("username");
    if (user != "") {
        alert("Welcome again " + user);
    }
    else {
        user = prompt("Please enter your name:", "");
        if (user != "" && user != null) {
            setCookie("username", user, 365);
        }
    }
}

$(document).ready(function () {
    function showDate() {
        var date = new Date();
        var html = getWeek(date.getUTCDay()) + "&nbsp;&nbsp;" + date.getFullYear() + "年" + (date.getMonth() + 1) + "月" + (date.getDate()) + "日&nbsp;&nbsp;" + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
        $('.date_time').html(html);
    }


    $('.main-body').css({'min-height': mtop - 35 + 'px'});
    setTimeout(showTime, '200');
    function getWeek(data) {
        switch (data) {
            case 0:
                return '星期日';
                break;
            case 1:
                return '星期一';
                break;
            case 2:
                return '星期二';
                break;
            case 3:
                return '星期三';
                break;
            case 4:
                return '星期四';
                break;
            case 5:
                return '星期五';
                break;
            case 6:
                return '星期六';
                break;

        }
    }

    function showWarm(htm) {
        $('.alert-warning .warning-content').html(htm);
        $('.alert-warning').show();
        setTimeout(hideWarm, '3000');
    }

    function hideWarm(htm) {
        $('.alert-warning').hide();
    }


    function showTime() {
        var today = new Date();
        $('.times.hour').text(today.getHours());
        $('.times.minut').text(today.getMinutes());

    }

    setInterval(showTime, 5000);
    setInterval(showDate, 1000);
    $('.tool-bar-left').css({'height': mtop + "px"});
    window.onresize = function () {
        var mtop = document.all ? document.getElementsByTagName("html")[0].offsetHeight : window.innerHeight;
        $('.tool-bar-left').css({'height': mtop + "px"});
    }
    $('.slideclosebtn-close').click(function () {
        console.log($(this).parent().css("margin-left"));
        if ($(this).parent().css("margin-left") == "0px") {
            $(this).parent().css({"margin-left": "-50px"});
            $(this).removeClass("glyphicon-arrow-left");
            $(this).addClass("glyphicon-arrow-right");
            $(this).css({"left": '50px'});
        } else {
            $(this).parent().css({"margin-left": "0px"});
            $(this).addClass("glyphicon-arrow-left");
            $(this).removeClass("glyphicon-arrow-right");
            $(this).css({"left": '0px'});
        }


    });
    $(" .app-icon").hover(function () {
            $(this).next().css({"display": "block"});
            $(this).css({"background": "#f7f7f7"});
        },
        function () {
            $(this).next().css({"display": "none"});
            $(this).css({"background": "none"});
        }
    )
    $(" .app-content").hover(function () {
            $(this).css({"display": "block"});
            $(this).prev().css({"background": "#f7f7f7"});
        },
        function () {
            $(this).css({"display": "none"});
            $(this).prev().css({"background": "none"});
        }
    )
})