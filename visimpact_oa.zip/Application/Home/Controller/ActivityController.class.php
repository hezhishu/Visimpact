<?php
namespace Home\Controller;
use Think\Controller;
class ActivityController extends BaseController {
    public function index(){
       $this->display();
    }
    public function add(){
        $this->display();
    }
    public function items(){
        $this->display();
    }
    public function detial(){
        $this->display();
    }
}