<?php
namespace Home\Controller;

use Think\Controller;
use Think\Upload;

class BaseController extends Controller
{
    private $public = array('login', 'register', 'loginin', 'reg', 'vcode');

    public function _initialize()
    {
        $this->_checkAuth();

    }

    protected function _checkAuth()
    {
        $this->checkLogin();
    }

    protected function checkLogin()
    {
        if (!in_array(strtolower(ACTION_NAME), $this->public)) {
            if (session('user.employees_id') && $this->checkUser(session('user.employees_id'))) {

            } else {

                $this->error('没有登录', U('login'));
            }
        } else {
            if (session('user.employees_id') && $this->checkUser(session('user.employees_id'))) {
                $this->success('已经登录', U('index'));
                exit;
            } else {

            }
        }

    }

    protected function checkUser($id)
    {
        $m = D('employees');
        return $m->field('email')->where(array('id' => $id))->find();
    }

    public function login()
    {
        $this->display();
    }

    public function loginIn()
    {
        if ($_POST) {
            $where['email'] = $_POST['email'];
            $where['password'] = md5($_POST['password']);
            $m = D('employees');
            $employee = $m->where($where)->find();
            if ($employee != false) {
                session('user.employees_id', $employee['id']);
                session('user.username', $employee['name']);
                session('user.email', $employee['email']);
                session('user.nickname', $employee['nickname']);
                cookie('user.username', $employee['name']);
                $iData = array();
                $iData['last_login_ip'] = $_SERVER['REMOTE_ADDR'];
                $m->where($where)->save($iData);

                $this->activeLog();
                $this->success("登录成功!", U("index/index"));
            } else {
                $this->activeLog(0);
                $this->error("用户名或密码错误.");

            }
        }
    }

    public function register()
    {
        $vcodeU = uniqid();
        $this->assign('unid', $vcodeU);
        $this->display();
    }

    public function vcode()
    {
        $Verify = new \Think\Verify();
        $Verify->entry(@$_GET['unid']);
    }

    public function reg()
    {
        if ($_POST) {
            $m = D('employees');
            $data = $_POST;
            $this->checkVcode($_POST['vcode'], $_POST['unid']) || $this->error("验证码错误.");
            !$this->checkEmail($_POST['email']) || $this->error("邮箱已经存在.");
            $data['confirm_password'] == $data['password'] || $this->error("密码不一致.");
            $data['password'] = md5($data['password']);
            $data['last_login_ip'] = $_SERVER['REMOTE_ADDR'];
            if ($m->add($data)) {
                session('user.employees_id', $m->getLastInsID());
                session('user.username', $_POST['name']);
                session('user.nickname', $_POST['nickname']);
                session('user.email', $_POST['email']);
                cookie('user.username', $_POST['name']);
                $this->activeLog(1);
                $this->success("注册成功", U("index/index"));
            }
        } else {
            $this->error("没有填写数据.");
        }
    }

    private function checkEmail($email)
    {
        $m = D('employees');
        $where['email'] = $email;
        return $m->field('email')->where($where)->find();

    }

    protected function checkVcode($vcode, $id)
    {
        $Verify = new \Think\Verify();
        return $Verify->check($vcode, $id);
    }

    protected function checkPassword($p1)
    {
        $m = D('employees');
        $where['password'] = md5($p1);
        return $m->field('email')->where($where)->find();
    }

    public function loginOut()
    {
        $this->activeLog($status = "1");
        session('user', null);

        $this->error('退出成功', U('index/login'));
    }

    protected function activeLog($status = "1")
    {
        $log = D('action_log');
        $data['action_name'] = ACTION_NAME;
        $data['client'] = $_SERVER['HTTP_USER_AGENT'];
        $data['referer'] = $_SERVER['HTTP_REFERER'];
        $data['request_url'] = $_SERVER['REQUEST_URI'];
        $data['employess_id'] = session('user.employees_id') ? session('user.employees_id') : 0;
        $data['status'] = $status;
        $data['ip'] = $_SERVER['REMOTE_ADDR'];
        $log->add($data);


    }

    public function iconUpload()
    {
        $upload = new Upload();
        $upload->maxSize = 1024 * 1024 * 20;// 设置附件上传大小
        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath = './Public/uploads/image/';
        $data = reset($_FILES);
        $mf = M('upload_img');
        $fi = $mf->where(array('name' => $data['name'], 'size' => $data['size']))->find();
        if ($fi != false) {
            echo json_encode($fi);
            return;
        } else {
            $info = $upload->uploadOne(reset($_FILES));
            if (!$info) {
                echo json_encode(array('error' => $upload->getError()));
                return;
            }
            $info['savepath'] = '/Public/Uploads/' . $info['savepath'];
            $info['upload_time'] = date('Y-m-d H:i:s');
            $info['actor'] = session('username');
            $mf->add($info);
            echo json_encode($info);
            return;
        }

        header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            exit; // finish preflight CORS requests here
        }


        if (!empty($_REQUEST['debug'])) {
            $random = rand(0, intval($_REQUEST['debug']));
            if ($random === 0) {
                header("HTTP/1.0 500 Internal Server Error");
                exit;
            }
        }

        @set_time_limit(5 * 60);

// $targetDir = ini_get("upload_tmp_dir") . DIRECTORY_SEPARATOR . "plupload";
        $targetDir = 'upload_tmp';
        $uploadDir = 'upload';

        $cleanupTargetDir = true; // Remove old files
        $maxFileAge = 5 * 3600; // Temp file age in seconds


// Create target dir
        if (!file_exists($targetDir)) {
            @mkdir($targetDir);
        }

// Create target dir
        if (!file_exists($uploadDir)) {
            @mkdir($uploadDir);
        }

// Get a file name
        if (isset($_REQUEST["name"])) {
            $fileName = $_REQUEST["name"];
        } elseif (!empty($_FILES)) {
            $fileName = $_FILES["file"]["name"];
        } else {
            $fileName = uniqid("file_");
        }
        $fileName=$this->unicode2utf8('"'.$fileName.'"');
        $fileName= iconv("UTF-8", "GBK", $fileName);//防止fopen语句失效
        $filePath = $targetDir . DIRECTORY_SEPARATOR . $fileName;
        $uploadPath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

// Chunking might be enabled
        $chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
        $chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 1;


// Remove old temp files
        if ($cleanupTargetDir) {
            if (!is_dir($targetDir) || !$dir = opendir($targetDir)) {
                die('{"jsonrpc" : "2.0", "error" : {"code": 100, "message": "Failed to open temp directory."}, "id" : "id"}');
            }

            while (($file = readdir($dir)) !== false) {
                $tmpfilePath = $targetDir . DIRECTORY_SEPARATOR . $file;

                // If temp file is current file proceed to the next
                if ($tmpfilePath == "{$filePath}_{$chunk}.part" || $tmpfilePath == "{$filePath}_{$chunk}.parttmp") {
                    continue;
                }

                // Remove temp file if it is older than the max age and is not the current file
                if (preg_match('/\.(part|parttmp)$/', $file) && (@filemtime($tmpfilePath) < time() - $maxFileAge)) {
                    @unlink($tmpfilePath);
                }
            }
            closedir($dir);
        }


// Open temp file
        if (!$out = @fopen("{$filePath}_{$chunk}.parttmp", "wb")) {
            die('{"jsonrpc" : "2.0", "error" : {"code": 102, "message": "Failed to open output stream."}, "id" : "id"}');
        }

        if (!empty($_FILES)) {
            if ($_FILES["file"]["error"] || !is_uploaded_file($_FILES["file"]["tmp_name"])) {
                die('{"jsonrpc" : "2.0", "error" : {"code": 103, "message": "Failed to move uploaded file."}, "id" : "id"}');
            }

            // Read binary input stream and append it to temp file
            if (!$in = @fopen($_FILES["file"]["tmp_name"], "rb")) {
                die('{"jsonrpc" : "2.0", "error" : {"code": 101, "message": "Failed to open input stream."}, "id" : "id"}');
            }
        } else {
            if (!$in = @fopen("php://input", "rb")) {
                die('{"jsonrpc" : "2.0", "error" : {"code": 101, "message": "Failed to open input stream."}, "id" : "id"}');
            }
        }

        while ($buff = fread($in, 4096)) {
            fwrite($out, $buff);
        }

        @fclose($out);
        @fclose($in);

        rename("{$filePath}_{$chunk}.parttmp", "{$filePath}_{$chunk}.part");

        $index = 0;
        $done = true;
        for ($index = 0; $index < $chunks; $index++) {
            if (!file_exists("{$filePath}_{$index}.part")) {
                $done = false;
                break;
            }
        }
        if ($done) {
            if (!$out = @fopen($uploadPath, "wb")) {
                die('{"jsonrpc" : "2.0", "error" : {"code": 102, "message": "Failed to open output stream."}, "id" : "id"}');
            }

            if (flock($out, LOCK_EX)) {
                for ($index = 0; $index < $chunks; $index++) {
                    if (!$in = @fopen("{$filePath}_{$index}.part", "rb")) {
                        break;
                    }

                    while ($buff = fread($in, 4096)) {
                        fwrite($out, $buff);
                    }

                    @fclose($in);
                    @unlink("{$filePath}_{$index}.part");
                }

                flock($out, LOCK_UN);
            }
            @fclose($out);
        }
        $arr = array(
            "jsonrpc" => "2.0",
            "result" => 1,
            "id" => "id",
            "src" => "/webuploader/server/" . $uploadPath,
        );
// Return Success JSON-RPC response
        echo json_encode($arr);

    }
   protected function unicode2Utf8($str){
        if(!$str) return $str;
        $decode = json_decode($str);
        if($decode) return $decode;
        $str = '["' . $str . '"]';
        $decode = json_decode($str);
        if(count($decode) == 1){
            return $decode[0];
        }
        return $str;
    }


}