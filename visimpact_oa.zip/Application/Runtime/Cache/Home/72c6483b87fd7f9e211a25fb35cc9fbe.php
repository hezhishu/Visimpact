<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="Robots" contect="noindex,follow,nofollow">
    <link rel="shortcut icon" href="#" type="image/png">

    <title><?php echo ($title); ?></title>

    <!--bootstrap-->
    <link href="../../public/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!--common-->
    <link href="../../public/bootstrap/css/style.css" rel="stylesheet">


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="../../public/bootstrap/js/html5shiv.min.js"></script>
    <script src="../../public/bootstrap/js/respond.min.js"></script>
    <![endif]-->
</head>
<body page="index">
<div class="container-fluid">
    <div class="header">
        <div class="container">
            <div class="logo"><p>湖北视纪印象科技股份有限公司 </p></div>
            <div class="user"><span class="user-name">欢迎您:<span><?php echo ($_SESSION['user']['username']); ?><a href="loginOut">退出</a></span> </span><span class="date_time"> </span></div>
        </div>
    </div>
    <div class="container main-body">
        <ol class="breadcrumb">
            <li><a href="<?php echo U('index/index');?>">首页</a></li>
            <li><a href="<?php echo U('activity/index');?>">活动管理</a></li>
            <li class="active">添加活动</li>
        </ol>
        <div class="col-md-12">
            <div class="form-activity" style="padding: 30px 10px;background: #fff;">

                <form class="form-horizontal" action="reg" role="form" style="background: #fff;" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="unid" id="unid" value="<?php echo ($unid); ?>">
                    <div class="form-group">
                        <label for="active_title" class="col-sm-3 control-label">活动主题</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="active_title" name="active_title"
                                   placeholder="请输入标题" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="stime" class="col-sm-3 control-label">开始时间</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="stime" name="stime"
                                   placeholder="请输入开始时间">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="etime" class="col-sm-3 control-label">结束时间</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="etime" name="etime"
                                   placeholder="请输入结束时间">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="image" class="col-sm-3 control-label">活动封面</label>
                        <div class="col-sm-9">
                            <div id="uploader">
                                <div class="queueList">
                                    <div id="dndArea" class="placeholder">
                                        <div id="filePicker"></div>
                                    </div>
                                </div>
                                <div class="statusBar" style="display:none;">
                                    <div class="progress">
                                        <span class="text">0%</span>
                                        <span class="percentage"></span>
                                    </div><div class="info"></div>
                                    <div class="btns">
                                        <div id="filePicker2"></div><div class="uploadBtn">开始上传</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="des" class="col-sm-3 control-label">活动描述</label>
                        <div class="col-sm-9">
                            <textarea   id="des" name="des"
                                    required></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                            <button type="submit" class="btn btn-info" id="activity-form">发布</button>
                        </div>
                    </div>
                </form>
                </div>


    </div>
</div>

<script src="../../public/bootstrap/js/jquery.min.js"></script>
<script src="../../public/bootstrap/js/bootstrap.min.js"></script>

<script src="../../public/bootstrap/js/common.js"></script>
<script src="../../public/bootstrap/js/rem.min.js"></script>
 <script src="../../public/bootstrap/js/jquery.datetimepicker.full.min.js"></script>
 <link href="../../public/bootstrap/css/jquery.datetimepicker.min.css" rel="stylesheet">
    <script type="text/javascript" charset="utf-8" src="../../public/ueditor/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="../../public/ueditor/ueditor.all.min.js"> </script>
    <script type="text/javascript" charset="utf-8" src="../../public/ueditor/lang/zh-cn/zh-cn.js"></script>
    <script type="text/javascript" charset="utf-8" src="../../public/webuploader/image-upload/webuploader.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="../../public/webuploader/image-upload/upload.js"></script>
    <link href="../../public/webuploader/image-upload/webuploader.css" rel="stylesheet">
    <link href="../../public/webuploader/image-upload/style.css" rel="stylesheet">
<script>
    $(document).ready(function () {
        if(getCookie('username')){
            $('.user-name span').text(getCookie('username'));
        }
        var ue = UE.getEditor('des');
        $.datetimepicker.setLocale('ch');
        // 路径配置
        $('#stime').datetimepicker({
            lang:'ch',
            timepickerScrollbar:false,
            format:'Y-m-d H:i',
            formatDate:'Y-m-d',
            formatTime:'H:i',
            formatDate:'Y-m-d',
        });
        $('#etime').datetimepicker({
            lang:'ch',
            timepickerScrollbar:false,
            format:'Y-m-d H:i',
            formatDate:'Y-m-d',
            formatTime:'H:i',
            formatDate:'Y-m-d',
        });
    })

</script>
<!-- 模态框（Modal） -->
<div class="modal fade" id="add-active-model" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-add-active">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    交流意愿
                </h4>
            </div>
            <div class="modal-body">
                <div class="form">


                    <form class="" role="form">
                        <div class="form-group">

                            <input type="text" class="form-control" id="firstname"
                                   placeholder="主题">

                        </div>
                        <div class="form-group">

                            <input type="time" class="form-control" id="date"
                                   placeholder="时间">

                        </div>
                        <div class="form-group">

                        <textarea  class="form-control" id="note"
                                   placeholder="备注" rows="5"></textarea>

                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-default">提交</button>
                            </div>
                            <br style="clear: both" >
                        </div>
                        <br style="clear: both" >
                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="tool-bar-left">
    <div class="slidetoolbar">
        <div class="applist">
            <div class="appwrap">
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        活动
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="<?php echo U('activity/add');?>" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span> 添加活动</a></div>
                        <div class="item"><a href="<?php echo U('activity/items');?>" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  活动预告</a></div>
                        <div class="item"><a href="<?php echo U('activity/history');?>" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  历史活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  技术&文档</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  经验分享</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>

            </div>
        </div></div>
    <a id="slidetoolbar-btn" class="glyphicon glyphicon-arrow-left slidetoolbar-closebtn slideclosebtn-close" hidefocus="true" href="javascript:void(0) " style="display: inline;" title="收起" alog-custom=""></a>
</div>
</body>
</html>