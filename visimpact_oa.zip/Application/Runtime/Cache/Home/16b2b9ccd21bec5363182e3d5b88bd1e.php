<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="Robots" contect="noindex,follow,nofollow">
    <link rel="shortcut icon" href="#" type="image/png">

    <title><?php echo ($title); ?></title>

    <!--bootstrap-->
    <link href="../../public/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!--common-->
    <link href="../../public/bootstrap/css/style.css" rel="stylesheet">


    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="../../public/bootstrap/js/html5shiv.min.js"></script>
    <script src="../../public/bootstrap/js/respond.min.js"></script>
    <![endif]-->
</head>
<body page="index">
<div class="container-fluid">
    <div class="header">
        <div class="container">
            <div class="logo"><p>湖北视纪印象科技股份有限公司 </p></div>
            <div class="user"><span class="user-name">欢迎您:<span><?php echo ($_SESSION['user']['username']); ?><a href="loginOut">退出</a></span> </span><span class="date_time"> </span></div>
        </div>
    </div>
    <div class="container main-body">
        <ul class="nav nav-tabs nav-justified">
            <li role="presentation" class="active"><a href="#home" data-toggle="tab">活动</a></li>
            <li role="presentation"><a href="#tongzhi" data-toggle="tab">通知</a></li>
            <li role="presentation"><a href="#svn" data-toggle="tab">考勤记录</a></li>
            <li role="presentation"><a href="#ios" data-toggle="tab">技术交流</a></li>
            <li role="presentation"><a href="#java" data-toggle="tab">公司制度</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade in active" id="home">
                <div class="row">
                    <div class="col-xs-6 col-sm-6">
                        <div class="box-fund qd-in">
                            <div class="icon-img">
                                <img src="../../public/images/qd_in.jpg"/>
                            </div>
                            <h2>上班</h2>
                        </div>
                    </div>
                    <div class="col-xs-6 col-sm-6">
                        <div class="box-fund qd-out">
                            <div class="icon-img">
                                <img src="../../public/images/qd_out.jpg"/>
                            </div>
                            <h2>下班</h2>
                        </div>

                    </div>
                </div>
                <div class="box-time">
                    <h4>现在时间</h4>
                    <div class="time-veiw">
                        <span class="times hour">15</span>
                        <span class="times dot">:</span>
                        <span class="times minut">55</span>

                    </div>
                    <h4>工作时间&nbsp;&nbsp; 8:30~17:30</h4>
                    <div class="arrow zs"></div>
                    <div class="arrow ys"></div>
                    <div class="arrow zx"></div>
                    <div class="arrow yx"></div>
                </div>

            </div>
            <div class="tab-pane fade" id="tongzhi">
                <div class="row">
                    <div class="col-xs-6 col-sm-6">
                        <div class="box-fund qd-in">
                            <div class="icon-img">
                                <img src="../../public/images/qd_in.jpg"/>
                            </div>
                            <h2>上班</h2>
                        </div>
                    </div>
                    <div class="col-xs-6 col-sm-6">
                        <div class="box-fund qd-out">
                            <div class="icon-img">
                                <img src="../../public/images/qd_out.jpg"/>
                            </div>
                            <h2>下班</h2>
                        </div>

                    </div>
                </div>
                <div class="box-time">
                    <h4>现在时间</h4>
                    <div class="time-veiw">
                        <span class="times hour">15</span>
                        <span class="times dot">:</span>
                        <span class="times minut">55</span>

                    </div>
                    <h4>工作时间&nbsp;&nbsp; 8:30~17:30</h4>
                    <div class="arrow zs"></div>
                    <div class="arrow ys"></div>
                    <div class="arrow zx"></div>
                    <div class="arrow yx"></div>
                </div>

            </div>
            <div class="tab-pane fade" id="svn">
                <div class="chart-ezp" id="chart-ezp" style="height: 700px; width:100%;position: relative;">


                </div>

            </div>
            <div class="tab-pane fade" id="ios">
                <div class="panel-group" id="accordion">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion"
                                   href="#collapseOne">
                                    以往技术交流信息
                                </a>
                            </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse in">
                            <div class="panel-body">

                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion"
                                   href="#collapseTwo">
                                    个人交流意愿方向
                                </a>
                            </h4>
                        </div>
                        <div id="collapseTwo" class="panel-collapse collapse">
                            <div class="panel-body">
                                <div class="tools-list">
                                <div class="add-active" data-toggle="modal" data-target="#add-active-model">
                                    <span class="tools-icon glyphicon glyphicon-plus"></span>
                                    <span class="tools-text">点击添加</span>
                                </div>
                                    <div class="add-active">
                                        <span class="tools-icon glyphicon glyphicon-plus"></span>
                                        <span class="tools-text">点击添加</span>
                                    </div>
                                    <div class="add-active">
                                        <span class="tools-icon glyphicon glyphicon-plus"></span>
                                        <span class="tools-text">点击添加</span>
                                    </div>
                                </div>
                                <div class="list">
                                    <table class="table table-hover">

                                        <thead>
                                        <tr>
                                            <th>编号</th>
                                            <th>主题</th>
                                            <th>时间</th>
                                            <th>备注</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr class="active">
                                            <td>1</td>
                                            <td>智慧信息</td>
                                            <td>2016-8-24</td>
                                            <td>交流学习</td>
                                        </tr>
                                        <tr class="success">
                                            <td>2</td>
                                            <td>智慧信息</td>
                                            <td>2016-8-24</td>
                                            <td>交流学习</td>
                                        </tr>
                                        <tr class="warning">
                                            <td>3</td>
                                            <td>智慧信息</td>
                                            <td>2016-8-24</td>
                                            <td>交流学习</td>
                                        </tr>
                                        <tr class="danger">
                                            <td>4</td>
                                            <td>智慧信息</td>
                                            <td>2016-8-24</td>
                                            <td>交流学习</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title">近期交流信息</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-6 col-md-3">
                                <div class="thumbnail">
                                    <img src="../../Public/images/qd_in.jpg"
                                         alt="通用的占位符缩略图">
                                    <div class="caption">
                                        <p>智能信息交流会</p>
                                        <p>2016-08-26</p>
                                        <p>
                                            <a href="#" class="btn btn-primary" role="button">
                                                参加
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <div class="thumbnail">
                                    <img src="../../Public/images/qd_in.jpg"
                                         alt="通用的占位符缩略图">
                                    <div class="caption">
                                        <p>智慧医疗交流会</p>
                                        <p>2016-08-29 上午2点</p>
                                        <p>
                                            <a href="#" class="btn btn-primary" role="button">
                                                参加
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <div class="thumbnail">
                                    <img src="../../Public/images/qd_in.jpg"
                                         alt="通用的占位符缩略图">
                                    <div class="caption">
                                        <p>智能信息交流会</p>
                                        <p>2016-08-26 上午2点</p>
                                        <p>
                                            <a href="#" class="btn btn-primary" role="button">
                                                参加
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3">
                                <div class="thumbnail">
                                    <img src="../../Public/images/qd_in.jpg"
                                         alt="通用的占位符缩略图">
                                    <div class="caption">
                                        <p>智能信息交流会</p>
                                        <p>2016-08-26 上午2点</p>
                                        <p>
                                            <a href="#" class="btn btn-primary" role="button">
                                                参加
                                            </a>
                                        </p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="java">

                <div class="panel-group" id="accordion1">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion1"
                                   href="#collapseOne1">
                                    财务制度
                                </a>
                            </h4>
                        </div>
                        <div id="collapseOne1" class="panel-collapse collapse in">
                            <div class="panel-body">
                                <ul class="list-group">
                                    <li class="list-group-item">考勤制度--2016-08-23</li>
                                    <li class="list-group-item">员工规范--2016-08-23</li>
                                    <li class="list-group-item">8月考勤记录--2016-08-23</li>
                                    <li class="list-group-item">
                                        <span class="badge">置顶</span>
                                        8月考勤记录--2016-08-23
                                    </li>
                                    <li class="list-group-item">保密协议--2016-08-23</li>
                                </ul>
                                <div class="page-tool">
                                    <ul class="pagination">
                                        <li><a href="#">&laquo;</a></li>
                                        <li><a href="#">1</a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a href="#">4</a></li>
                                        <li><a href="#">5</a></li>
                                        <li><a href="#">&raquo;</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion1"
                                   href="#collapseTwo1">
                                    报销制度
                                </a>
                            </h4>
                        </div>
                        <div id="collapseTwo1" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="list-group">
                                    <li class="list-group-item">考勤制度--2016-08-23</li>
                                    <li class="list-group-item">员工规范--2016-08-23</li>
                                    <li class="list-group-item">8月考勤记录--2016-08-23</li>
                                    <li class="list-group-item">
                                        <span class="badge">置顶</span>
                                        8月考勤记录--2016-08-23
                                    </li>
                                    <li class="list-group-item">保密协议--2016-08-23</li>
                                </ul>
                                <div class="page-tool">
                                    <ul class="pagination">
                                        <li><a href="#">&laquo;</a></li>
                                        <li><a href="#">1</a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a href="#">4</a></li>
                                        <li><a href="#">5</a></li>
                                        <li><a href="#">&raquo;</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion1"
                                   href="#collapseThree1">
                                    考勤制度
                                </a>
                            </h4>
                        </div>
                        <div id="collapseThree1" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="list-group">
                                    <li class="list-group-item">考勤制度--2016-08-23</li>
                                    <li class="list-group-item">员工规范--2016-08-23</li>
                                    <li class="list-group-item">8月考勤记录--2016-08-23</li>
                                    <li class="list-group-item">
                                        <span class="badge">置顶</span>
                                        8月考勤记录--2016-08-23
                                    </li>
                                    <li class="list-group-item">保密协议--2016-08-23</li>
                                </ul>
                                <div class="page-tool">
                                    <ul class="pagination">
                                        <li><a href="#">&laquo;</a></li>
                                        <li><a href="#">1</a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a href="#">4</a></li>
                                        <li><a href="#">5</a></li>
                                        <li><a href="#">&raquo;</a></li>
                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="../../public/bootstrap/js/jquery.min.js"></script>
<script src="../../public/bootstrap/js/bootstrap.min.js"></script>
<script src="../../public/bootstrap/js/canvas.combine.js"></script>
<script src="../../public/bootstrap/js/echarts.js"></script>

<script src="../../public/bootstrap/js/common.js">



</script>
<script src="../../public/bootstrap/js/rem.min.js"></script>
<script src="../../public/bootstrap/js/data.js"></script>
<script>
    $(document).ready(function () {
        if(getCookie('username')){
            $('.user-name span').text(getCookie('username'));
        }
        // 路径配置
        function Json2Data(val){
            var j = eval(val);
            var d = [];
            var len = val.length;
            var x = 0;

            while(len--)
            {
                var str= val[x].toString()  ;
                var arr = str.split(",") ;

                var newtime = new Date(
                        parseInt(arr[0]),
                        parseInt(arr[1])-1,
                        parseInt(arr[2]),
                        parseInt(arr[3]),
                        parseInt(arr[4]),
                        parseInt(arr[5])) ;


                var yt = '2015-1-1'+ ' '+ arr[3] +':'+arr[4]+':'+arr[5];

                yt = yt.replace(/-/g,'/');

                var ytime= new Date(yt);
                //document.write(ytime + '<br>');

                var ty = ytime.getTime();
                //document.write(ty + '<br>');
                d.push([new Date(newtime) ,ytime,30,arr[6]]);

                x++;
            }

            return d;
        };
        function checkTime(i)
        {
            if (i<10)
            {i="0" + i}
            return i
        };
        function A(){

            require.config({
                paths: {
                    echarts: '../../public/bootstrap/js'
                }
            });
            // 使用
            require(
                    [
                        'echarts',
                        'echarts/chart/scatter' //
                    ],

                    function(ec) {
                        // 基于准备好的dom，初始化echarts图表
                        var myChart = ec.init(document.getElementById('chart-ezp'));


                        option = {
                            title: {
                                subtext: '文化旅游事业部技术支持',
                                x : 'center',
                                //sublink: 'http://www.visimpact.cn'
                            },

                            tooltip : {
                                trigger: 'axis',
                                formatter : function (params) {
                                    var date = new Date(params.value[0]);
                                    return params.seriesName
                                            +  ' <br/>'
                                            +params.value[3]
                                            +  ' <br/>'
                                            + '['
                                            + date.getFullYear() + '-'
                                            + (date.getMonth() + 1) + '-'
                                            + date.getDate() + ' '
                                            + date.getHours() + ':'
                                            + date.getMinutes()   + ']';
                                },
                                axisPointer:{
                                    show: true,
                                    type : 'shadow',

                                }
                            },


                            legend: {
                                textStyle:{
                                    fontSize:18,
                                },
                                data:['早起的鸟儿','迟到的虫子','苦比的秋刀鱼','勤劳的水牛']
                            },

                            yAxis : [
                                {

                                    type : 'time' ,
                                    axisLabel:{
                                        textStyle:{
                                            fontSize:18,
                                        },
                                        formatter:function(val)
                                        {
                                            var m = val.getMinutes() ;
                                            return checkTime(val.getHours()) + ":" + checkTime(val.getMinutes());
                                        }
                                    } ,
                                    /*
                                     makeline:{

                                     data:[
                                     {name: '标线2起点', value: 200, xAxis: 10, yAxis: 20},
                                     {name: '标线2终点', xAxis: 270, yAxis: 190}
                                     ]
                                     },*/
                                    splitLine: {show:false},

                                }
                            ],

                            xAxis : [
                                {

                                    type : 'time',
                                    min:new Date("2015/05/1"),
                                    max:new Date("2015/05/30"),
                                    splitNumber:18  ,
                                    splitLine: {show:false} ,
                                }
                            ],
                            calculable : true,
                            series : [
                                {
                                    name:'早起的鸟儿',
                                    type:'scatter',
                                    data:(Json2Data(QiZaoval))

                                },
                                {
                                    name:'迟到的虫子',
                                    type:'scatter',
                                    large: true,
                                    data:(Json2Data(Chidaoval))

                                },
                                {
                                    name:'勤劳的水牛',
                                    type:'scatter',
                                    large: true,
                                    data:(Json2Data(JiaBanval))

                                },
                                {
                                    name:'苦比的秋刀鱼',
                                    type:'scatter',
                                    large: true,
                                    data:(Json2Data(XiaBanval))

                                }

                            ]
                        };
                        // 为echarts对象加载数据
                        myChart.setOption(option) ;

                    }

            );
        }

        var Chidaoval=[];
        var QiZaoval=[];
        var XiaBanval=[];
        var JiaBanval=[];
        window.onload= InitLoad;
        function InitLoad(){

                    $("#chart-ezp").css({'width':$(".tab-content").width()+"px"});
                    var cont = testData;

                    var j = eval(cont);

                    var len = j.length;
                    var x = 0;

                    while(len--)
                    {
                        var str= j[x].time.toString() ;
                        var arr = str.split(",") ;
                        var standTime0=  new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]),
                                parseInt(arr[2]),
                                00,
                                00,
                                00 );
                        var standTime00=  new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]),
                                parseInt(arr[2]),
                                06,
                                30,
                                00 );
                        var standTime=  new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]),
                                parseInt(arr[2]),
                                08,
                                30,
                                00 );
                        var standTime2=  new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]),
                                parseInt(arr[2]),
                                12,
                                00,
                                00 );
                        var standTime3=  new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]),
                                parseInt(arr[2]),
                                17,
                                30,
                                00 );
                        var standTime4=  new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]),
                                parseInt(arr[2]),
                                20,
                                30,
                                00 );
                        var activeTime = new Date(
                                parseInt(arr[0]),
                                parseInt(arr[1]) ,
                                parseInt(arr[2]),
                                parseInt(arr[3]),
                                parseInt(arr[4]),
                                parseInt(arr[5])) ;
                        if (standTime < activeTime && standTime2 > activeTime) {

                            Chidaoval.push(str+ ',' + j[x].name);
                        }
                        else if (standTime >= activeTime && standTime00 <= activeTime) {
                            QiZaoval.push(str+ ',' + j[x].name);
                        }
                        else if (standTime4 <= activeTime   ) {
                            JiaBanval.push(str+ ',' + j[x].name);
                        }
                        else if (standTime0 <= activeTime  && standTime00 >= activeTime  ) {
                            JiaBanval.push(str+ ',' + j[x].name);
                        }
                        else if (standTime3 <= activeTime && standTime4 > activeTime  ) {
                            XiaBanval.push(str+ ',' + j[x].name);
                        }
                        x++;

                    }

                    A();
                }






    })

</script>
<!-- 模态框（Modal） -->
<div class="modal fade" id="add-active-model" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-add-active">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"
                        aria-hidden="true">×
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    交流意愿
                </h4>
            </div>
            <div class="modal-body">
                <div class="form">


                <form class="" role="form">
                    <div class="form-group">

                            <input type="text" class="form-control" id="firstname"
                                   placeholder="主题">

                    </div>
                    <div class="form-group">

                            <input type="time" class="form-control" id="date"
                                   placeholder="时间">

                    </div>
                    <div class="form-group">

                        <textarea  class="form-control" id="note"
                               placeholder="备注" rows="5"></textarea>

                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-default">提交</button>
                        </div>
                        <br style="clear: both" >
                    </div>
                    <br style="clear: both" >
                </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="tool-bar-left">
    <div class="slidetoolbar">
        <div class="applist">
            <div class="appwrap">
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        活动
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="<?php echo U('activity/add');?>" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>
                <div class="appitem">
                    <a class="app-icon" href="javascript:void(0)">
                        <span class=" glyphicon glyphicon-picture"></span>
                        第一个
                    </a>
                    <div class="app-content">
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                        <div class="item"><a href="#" class="" style="display: block;"><span class="glyphicon glyphicon-tint"></span>  添加活动</a></div>
                    </div>
                </div>

    </div>
            </div></div>
    <a id="slidetoolbar-btn" class="glyphicon glyphicon-arrow-left slidetoolbar-closebtn slideclosebtn-close" hidefocus="true" href="javascript:void(0) " style="display: inline;" title="收起" alog-custom=""></a>
</div>
</body>
</html>