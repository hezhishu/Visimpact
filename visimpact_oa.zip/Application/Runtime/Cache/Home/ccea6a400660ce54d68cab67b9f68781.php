<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
   <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="keywords" content="admin, dashboard, bootstrap, template, flat, modern, theme, responsive, fluid, retina, backend, html5, css, css3">
  <meta name="description" content="">
  <meta name="Robots" contect="noindex,follow,nofollow">
  <meta name="author" content="ThemeBucket">
  <link rel="shortcut icon" href="#" type="image/png">

  <title><?php echo ($title); ?></title>

  <!--bootstrap-->
  <link href="../../public/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <!--common-->
  <link href="../../public/bootstrap/css/style.css" rel="stylesheet">
  <link href="../../public/bootstrap/css/login.css" rel="stylesheet">


  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 8]>
  <script src="../../public/bootstrap/js/html5shiv.min.js"></script>
      <script src="../../public/bootstrap/js/respond.min.js"></script>
  <![endif]-->
</head>
<body page="index">
<div class="container-fluid">
  <div class="header">
    <div class="container">
      <div class="logo"><p>湖北视纪印象科技股份有限公司 </p></div>
      <div class="user"><span class="date_time"> </span></div>
    </div>
  </div>
  <div class="container main-body">
    <div class="jumbotron">
      <div class="row">
        <div class="col-md-6 visible-md visible-lg">
          <h1>Hello,朋友!</h1>
          <p>欢迎来到视纪印象大家庭!</p>
          <p><a class="btn btn-primary" role="button">
            了解更多</a>
          </p>
        </div>
        <div class="col-md-6">
          <div class="form-login">

          <form class="form-horizontal" action="loginIn" role="form" style="background: #fff;" method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label for="email" class="col-sm-3 control-label">用户名</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="email" name="email"
                       placeholder="请输入名字" required>
              </div>
            </div>
            <div class="form-group">
              <label for="password" class="col-sm-3 control-label">密码</label>
              <div class="col-sm-9">
                <input type="password" class="form-control" id="password" name="password"
                       placeholder="请输入密码" required>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-3 col-sm-9">
                <div class="checkbox">
                  <label>
                    <input name="kit_me" type="checkbox"> 请记住我
                  </label>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-3 col-sm-9">
                <button type="submit" class="btn btn-default" id="login-form">登录</button>
              </div>
            </div>
          </form>
      <p style="text-align: center;font-size: 12px;">没有账号?<a href="register" >注册</a></p>

</div>
        </div>

      </div>

    </div>
  </div>
</div>

<script src="../../public/bootstrap/js/jquery.min.js"></script>
<script src="../../public/bootstrap/js/bootstrap.min.js"></script>
<script src="../../public/bootstrap/js/common.js"></script>
<script src="/Public/bootstrap/js/validator/jquery.validate.min.js"></script>
<script src="/Public/bootstrap/js/validator/messages_zh.js"></script>
<script>
  $(function(){
    /*$('#login-form').click(function(){
      if($('#username').val()!="" && $('#password').val()!=""){
        setCookie('username',$('#username').val());
        setCookie('password',$('#password').val());
        window.location.href="index.html";
      }else{
        showWarm('用户名或密码错误!');
      }
    })*/
    $(".form-horizontal").validate({
      rules: {
        password: {
          required: true,
          minlength: 6
        },

        email: {
          required: true,
          email: true
        },
      },
      messages: {
        password: {
          required: "请输入密码",
          minlength: "密码长度不能小于 6 个字母"
        },
        email: "请输入一个正确的邮箱"
      }
    });
  });
</script>
<div class="alert alert-warning" style="display: none;">
  <div class="warning-content">
    <strong>警告！</strong>您的网络连接有问题。
  </div>

</div>
</body>
</html>