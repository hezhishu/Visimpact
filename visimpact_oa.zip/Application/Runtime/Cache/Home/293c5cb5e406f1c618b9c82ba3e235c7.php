<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
   <meta http-equiv="X-UA-Compatible" content="IE=9">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="keywords" content="admin, dashboard, bootstrap, template, flat, modern, theme, responsive, fluid, retina, backend, html5, css, css3">
  <meta name="description" content="">
  <meta name="Robots" contect="noindex,follow,nofollow">
  <meta name="author" content="ThemeBucket">
  <link rel="shortcut icon" href="#" type="image/png">

  <title><?php echo ($title); ?></title>

  <!--bootstrap-->
  <link href="../../public/bootstrap/css/bootstrap.min.css" rel="stylesheet">


  <!--common-->
  <link href="../../public/bootstrap/css/style.css" rel="stylesheet">
  <link href="../../public/bootstrap/css/login.css" rel="stylesheet">


  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 8]>
  <script src="../../public/bootstrap/js/html5shiv.min.js"></script>
      <script src="../../public/bootstrap/js/respond.min.js"></script>
  <![endif]-->
</head>
<body page="index">
<div class="container-fluid">
  <div class="header">
    <div class="container">
      <div class="logo"><p>湖北视纪印象科技股份有限公司 </p></div>
      <div class="user"><span class="date_time"> </span></div>
    </div>
  </div>
  <div class="container main-body">
    <div class="jumbotron">
      <div class="row">

        <div class="col-md-12">
          <div class="form-login">

          <form class="form-horizontal" action="_register" role="form" style="background: #fff;" method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label for="nickname" class="col-sm-3 control-label">姓名</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="name" name="name"
                       placeholder="请输入姓名" required>
              </div>
            </div>
            <div class="form-group">
              <label for="nickname" class="col-sm-3 control-label">昵称</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="nickname" name="nickname"
                       placeholder="请输入昵称">
              </div>
            </div>
            <div class="form-group">
              <label for="email" class="col-sm-3 control-label">邮箱</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="email" name="email"
                       placeholder="请输入公司企业邮箱" required>
              </div>
            </div>
           <!-- <div class="form-group">
              <label for="email" class="col-sm-3 control-label">手机号码</label>
              <div class="col-sm-9">
                <input type="text" class="form-control" id="telephone" name="telephone"
                       placeholder="请输入手机号码">
              </div>
            </div>-->
            <div class="form-group">
              <label for="password" class="col-sm-3 control-label">密码</label>
              <div class="col-sm-9">
                <input type="password" class="form-control" id="password" name="password"
                       placeholder="请输入密码" required>
              </div>
            </div>
            <div class="form-group">
              <label for="password" class="col-sm-3 control-label">确认密码</label>
              <div class="col-sm-9">
                <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                       placeholder="请输入密码" required>
              </div>
            </div>

            <div class="form-group">
              <label for="password" class="col-sm-3 control-label">验证码</label>
              <div class="col-sm-4">
                <input type="password" class="form-control" id="vcode" name="vcode"
                       placeholder="请输入验证码" required>
              </div>
              <div class="col-sm-5">

               <img style="max-width: 150px;" src="<?php echo U('vcode','rand='.rand(0,99999));?>">
                <a href="javascript:void(0)"  id="change-vcode">换一个</a>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-3 col-sm-9">
                <button type="submit" class="btn btn-info" id="register-form">注册</button>
              </div>
            </div>
          </form>
<p style="text-align: center;font-size: 12px;">已有账号?<a href="login" >登录</a></p>

</div>
        </div>

      </div>

    </div>
  </div>
</div>

<script src="../../public/bootstrap/js/jquery.min.js"></script>
<script src="../../public/bootstrap/js/bootstrap.min.js"></script>
<script src="../../public/bootstrap/js/bootstrap.min.js"></script>
<script src="../../public/bootstrap/js/common.js">


</script>
<script src="/Public/bootstrap/js/validator/jquery.validate.min.js"></script>
<script src="/Public/bootstrap/js/validator/messages_zh.js"></script>

<script>
  $(function(){
    $(".form-horizontal").validate({
      rules: {
        password: {
          required: true,
          minlength: 6
        },
        name: {
          required: true,
          minlength: 2
        },
        nickname: {
          required: true,
          minlength: 2
        },
        confirm_password: {
          required: true,
          minlength: 5,
          equalTo: "#password"
        },
        email: {
          required: true,
          email: true
        },
      },
      messages: {
        nickname: {
          required: "请输入昵称",
          minlength: "昵称必需由两个以上字母组成"
        },
        name: {
          required: "请输入姓名",
          minlength: "昵称必需由两个以上汉字组成"
        },
        password: {
          required: "请输入密码",
          minlength: "密码长度不能小于 6 个字母"
        },
        confirm_password: {
          required: "请输入密码",
          minlength: "密码长度不能小于 6 个字母",
          equalTo: "两次密码输入不一致"
        },
        email: "请输入一个正确的邮箱"
      }
    });
    $("#change-vcode").click(function(){
      $(this).prev().attr('src','vcode?rand='+Math.random());

    });
  });
</script>
<div class="alert alert-warning" style="display: none;">
  <div class="warning-content">
    <strong>警告！</strong>您的网络连接有问题。
  </div>

</div>
</body>
</html>